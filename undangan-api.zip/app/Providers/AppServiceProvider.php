<?php

namespace App\Providers;

use Core\Facades\Provider;

class AppServiceProvider extends Provider
{
    /**
     * Registrasi apa aja disini
     *
     * @return void
     */
    public function registrasi()
    {
        //
    }

    /**
     * Jalankan sewaktu aplikasi dinyalakan
     *
     * @return void
     */
    public function booting()
    {
        //
    }
}
