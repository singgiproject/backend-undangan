<?php

namespace App\Models;

use Core\Model\Model;

final class Comment extends Model
{
    protected $table = 'comments';
}
